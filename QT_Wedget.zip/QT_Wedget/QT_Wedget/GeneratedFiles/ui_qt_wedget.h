/********************************************************************************
** Form generated from reading UI file 'qt_wedget.ui'
**
** Created by: Qt User Interface Compiler version 5.5.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_QT_WEDGET_H
#define UI_QT_WEDGET_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QCheckBox>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QToolBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_QT_WedgetClass
{
public:
    QWidget *centralWidget;
    QCheckBox *checkBox;
    QPushButton *pushButton;
    QMenuBar *menuBar;
    QToolBar *mainToolBar;
    QStatusBar *statusBar;

    void setupUi(QMainWindow *QT_WedgetClass)
    {
        if (QT_WedgetClass->objectName().isEmpty())
            QT_WedgetClass->setObjectName(QStringLiteral("QT_WedgetClass"));
        QT_WedgetClass->resize(600, 400);
        centralWidget = new QWidget(QT_WedgetClass);
        centralWidget->setObjectName(QStringLiteral("centralWidget"));
        checkBox = new QCheckBox(centralWidget);
        checkBox->setObjectName(QStringLiteral("checkBox"));
        checkBox->setGeometry(QRect(150, 100, 71, 16));
        pushButton = new QPushButton(centralWidget);
        pushButton->setObjectName(QStringLiteral("pushButton"));
        pushButton->setGeometry(QRect(320, 100, 75, 23));
        QT_WedgetClass->setCentralWidget(centralWidget);
        menuBar = new QMenuBar(QT_WedgetClass);
        menuBar->setObjectName(QStringLiteral("menuBar"));
        menuBar->setGeometry(QRect(0, 0, 600, 23));
        QT_WedgetClass->setMenuBar(menuBar);
        mainToolBar = new QToolBar(QT_WedgetClass);
        mainToolBar->setObjectName(QStringLiteral("mainToolBar"));
        QT_WedgetClass->addToolBar(Qt::TopToolBarArea, mainToolBar);
        statusBar = new QStatusBar(QT_WedgetClass);
        statusBar->setObjectName(QStringLiteral("statusBar"));
        QT_WedgetClass->setStatusBar(statusBar);

        retranslateUi(QT_WedgetClass);
        QObject::connect(checkBox, SIGNAL(clicked()), QT_WedgetClass, SLOT(on_checkBox_clicked()));

        QMetaObject::connectSlotsByName(QT_WedgetClass);
    } // setupUi

    void retranslateUi(QMainWindow *QT_WedgetClass)
    {
        QT_WedgetClass->setWindowTitle(QApplication::translate("QT_WedgetClass", "QT_Wedget", 0));
        checkBox->setText(QApplication::translate("QT_WedgetClass", "CheckBox", 0));
        pushButton->setText(QApplication::translate("QT_WedgetClass", "pushbotton", 0));
    } // retranslateUi

};

namespace Ui {
    class QT_WedgetClass: public Ui_QT_WedgetClass {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_QT_WEDGET_H
