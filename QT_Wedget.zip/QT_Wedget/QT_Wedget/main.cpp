#include "qt_wedget.h"
#include <QtWidgets/QApplication>

int main(int argc, char *argv[])
{
	QApplication a(argc, argv);
	QT_Wedget w;
	w.show();
	return a.exec();
}
