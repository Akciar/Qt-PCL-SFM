#include "qt_wedget.h"

QT_Wedget::QT_Wedget(QWidget *parent)
	: QMainWindow(parent)
{
	ui.setupUi(this);
	/*connect(ui.checkBox, SIGNAL(clicked()), this, SLOT(on_checkBox_clicked()));
	connect(ui.pushButton, SIGNAL(clicked()), this, SLOT(on_pushButton_clicked()));*/
}
void QT_Wedget::on_checkBox_clicked()
{
	if (ui.checkBox->isChecked())
	{
		/*ui.lineEdit->setReadOnly(true);*/
	}
	else
	{
		/*ui.result->setReadOnly(false);*/
	}
}

void QT_Wedget::on_pushButton_clicked()
{
	/*ui.label->setText(ui.lineEdit->text());*/
}