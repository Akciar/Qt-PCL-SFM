#pragma once

#include <QtWidgets/QMainWindow>
#include "ui_qt_wedget.h"

class QT_Wedget : public QMainWindow
{
	Q_OBJECT

public:
	QT_Wedget(QWidget *parent = Q_NULLPTR);

private:
	Ui::QT_WedgetClass ui;

private slots:
	void on_checkBox_clicked();
	void on_pushButton_clicked();
};
